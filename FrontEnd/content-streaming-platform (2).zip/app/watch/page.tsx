"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Search, Play, Star, Filter, Grid, List, ChevronDown, X } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

const movies = [
  {
    id: 1,
    title: "The Dark Knight",
    year: "2008",
    rating: 9.0,
    genre: ["Action", "Crime", "Drama"],
    image: "/placeholder.svg?height=450&width=300",
    platforms: ["Netflix", "HBO Max"],
    description:
      "When the menace known as the Joker wreaks havoc and chaos on the people of Gotham, Batman must accept one of the greatest psychological and physical tests.",
    director: "Christopher Nolan",
    cast: ["Christian Bale", "Heath Ledger", "Aaron Eckhart"],
    duration: "152 min",
    trending: true,
  },
  {
    id: 2,
    title: "Stranger Things",
    year: "2022",
    rating: 8.7,
    genre: ["Drama", "Fantasy", "Horror"],
    image: "/placeholder.svg?height=450&width=300",
    platforms: ["Netflix"],
    description:
      "When a young boy disappears, his mother, a police chief and his friends must confront terrifying supernatural forces.",
    director: "The Duffer Brothers",
    cast: ["Millie Bobby Brown", "Finn Wolfhard", "David Harbour"],
    duration: "8 episodes",
    trending: true,
  },
  {
    id: 3,
    title: "Dune",
    year: "2021",
    rating: 8.0,
    genre: ["Action", "Adventure", "Drama"],
    image: "/placeholder.svg?height=450&width=300",
    platforms: ["HBO Max", "Amazon Prime"],
    description: "A noble family becomes embroiled in a war for control over the galaxy's most valuable asset.",
    director: "Denis Villeneuve",
    cast: ["Timothée Chalamet", "Rebecca Ferguson", "Oscar Isaac"],
    duration: "155 min",
    trending: false,
  },
  {
    id: 4,
    title: "The Mandalorian",
    year: "2023",
    rating: 8.8,
    genre: ["Action", "Adventure", "Fantasy"],
    image: "/placeholder.svg?height=450&width=300",
    platforms: ["Disney+"],
    description:
      "The travels of a lone bounty hunter in the outer reaches of the galaxy, far from the authority of the New Republic.",
    director: "Jon Favreau",
    cast: ["Pedro Pascal", "Gina Carano", "Carl Weathers"],
    duration: "3 seasons",
    trending: true,
  },
  {
    id: 5,
    title: "Top Gun: Maverick",
    year: "2022",
    rating: 8.3,
    genre: ["Action", "Drama"],
    image: "/placeholder.svg?height=450&width=300",
    platforms: ["Paramount+", "Amazon Prime"],
    description: "After thirty years, Maverick is still pushing the envelope as a top naval aviator.",
    director: "Joseph Kosinski",
    cast: ["Tom Cruise", "Miles Teller", "Jennifer Connelly"],
    duration: "130 min",
    trending: false,
  },
  {
    id: 6,
    title: "House of the Dragon",
    year: "2022",
    rating: 8.5,
    genre: ["Action", "Adventure", "Drama"],
    image: "/placeholder.svg?height=450&width=300",
    platforms: ["HBO Max"],
    description:
      "An internal succession war within House Targaryen at the height of its power, 172 years before the birth of Daenerys.",
    director: "Ryan Condal",
    cast: ["Paddy Considine", "Emma D'Arcy", "Matt Smith"],
    duration: "10 episodes",
    trending: true,
  },
]

const genres = ["All", "Action", "Adventure", "Comedy", "Crime", "Drama", "Fantasy", "Horror", "Sci-Fi", "Thriller"]
const platforms = ["All Platforms", "Netflix", "HBO Max", "Disney+", "Amazon Prime", "Paramount+", "Apple TV+"]
const years = ["All Years", "2024", "2023", "2022", "2021", "2020", "2019", "2018"]

export default function WatchPage() {
  const [selectedGenre, setSelectedGenre] = useState("All")
  const [selectedPlatform, setSelectedPlatform] = useState("All Platforms")
  const [selectedYear, setSelectedYear] = useState("All Years")
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid")
  const [showFilters, setShowFilters] = useState(false)
  const [selectedMovie, setSelectedMovie] = useState<(typeof movies)[0] | null>(null)

  const filteredMovies = movies.filter((movie) => {
    const genreMatch = selectedGenre === "All" || movie.genre.includes(selectedGenre)
    const platformMatch = selectedPlatform === "All Platforms" || movie.platforms.includes(selectedPlatform)
    const yearMatch = selectedYear === "All Years" || movie.year === selectedYear
    return genreMatch && platformMatch && yearMatch
  })

  const trendingMovies = movies.filter((movie) => movie.trending)

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Navigation */}
      <nav className="fixed top-0 w-full z-50 bg-black/90 backdrop-blur-md border-b border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link href="/" className="text-2xl font-bold text-red-500">
              StreamNews
            </Link>
            <div className="flex items-center space-x-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search movies & series..."
                  className="pl-10 bg-gray-900 border-gray-700 text-white placeholder-gray-400 w-64"
                />
              </div>
            </div>
          </div>
        </div>
      </nav>

      <div className="pt-16">
        {/* Hero Section */}
        <section className="relative h-96 overflow-hidden">
          <Image
            src="/placeholder.svg?height=400&width=1440"
            alt="Watch Movies & Series"
            fill
            className="object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/40 to-transparent" />
          <div className="relative z-10 flex items-center h-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div>
              <h1 className="text-5xl font-bold mb-4">Watch Movies & Series</h1>
              <p className="text-xl text-gray-300 max-w-2xl">
                Discover and stream the latest movies and TV series from all major platforms
              </p>
            </div>
          </div>
        </section>

        {/* Trending Section */}
        <section className="py-12 bg-gray-950">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <h2 className="text-2xl font-bold mb-6">Trending Now</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
              {trendingMovies.map((movie) => (
                <div key={movie.id} className="relative group cursor-pointer" onClick={() => setSelectedMovie(movie)}>
                  <div className="relative overflow-hidden rounded-lg">
                    <Image
                      src={movie.image || "/placeholder.svg"}
                      alt={movie.title}
                      width={300}
                      height={450}
                      className="object-cover w-full h-64 group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                      <Play className="w-12 h-12 text-white" />
                    </div>
                    <Badge className="absolute top-2 left-2 bg-red-600">Trending</Badge>
                  </div>
                  <h3 className="font-semibold mt-2 text-sm">{movie.title}</h3>
                  <div className="flex items-center mt-1">
                    <Star className="w-3 h-3 text-yellow-500 mr-1" />
                    <span className="text-xs text-gray-400">{movie.rating}</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Filters and Content */}
        <section className="py-8 bg-black">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            {/* Filter Bar */}
            <div className="flex items-center justify-between mb-8">
              <div className="flex items-center space-x-4">
                <Button variant="outline" onClick={() => setShowFilters(!showFilters)} className="border-gray-700">
                  <Filter className="w-4 h-4 mr-2" />
                  Filters
                  <ChevronDown className={`w-4 h-4 ml-2 transition-transform ${showFilters ? "rotate-180" : ""}`} />
                </Button>

                {showFilters && (
                  <div className="flex items-center space-x-4">
                    <Select value={selectedGenre} onValueChange={setSelectedGenre}>
                      <SelectTrigger className="w-32 bg-gray-900 border-gray-700">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {genres.map((genre) => (
                          <SelectItem key={genre} value={genre}>
                            {genre}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>

                    <Select value={selectedPlatform} onValueChange={setSelectedPlatform}>
                      <SelectTrigger className="w-40 bg-gray-900 border-gray-700">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {platforms.map((platform) => (
                          <SelectItem key={platform} value={platform}>
                            {platform}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>

                    <Select value={selectedYear} onValueChange={setSelectedYear}>
                      <SelectTrigger className="w-32 bg-gray-900 border-gray-700">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {years.map((year) => (
                          <SelectItem key={year} value={year}>
                            {year}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                )}
              </div>

              <div className="flex items-center space-x-2">
                <Button
                  variant={viewMode === "grid" ? "default" : "outline"}
                  size="icon"
                  onClick={() => setViewMode("grid")}
                  className="border-gray-700"
                >
                  <Grid className="w-4 h-4" />
                </Button>
                <Button
                  variant={viewMode === "list" ? "default" : "outline"}
                  size="icon"
                  onClick={() => setViewMode("list")}
                  className="border-gray-700"
                >
                  <List className="w-4 h-4" />
                </Button>
              </div>
            </div>

            {/* Content Grid/List */}
            <Tabs defaultValue="all" className="w-full">
              <TabsList className="grid w-full grid-cols-3 bg-gray-900">
                <TabsTrigger value="all">All Content</TabsTrigger>
                <TabsTrigger value="movies">Movies</TabsTrigger>
                <TabsTrigger value="series">TV Series</TabsTrigger>
              </TabsList>

              <TabsContent value="all" className="mt-8">
                {viewMode === "grid" ? (
                  <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-6">
                    {filteredMovies.map((movie) => (
                      <div key={movie.id} className="group cursor-pointer" onClick={() => setSelectedMovie(movie)}>
                        <div className="relative overflow-hidden rounded-lg">
                          <Image
                            src={movie.image || "/placeholder.svg"}
                            alt={movie.title}
                            width={300}
                            height={450}
                            className="object-cover w-full h-80 group-hover:scale-105 transition-transform duration-300"
                          />
                          <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                            <Play className="w-12 h-12 text-white" />
                          </div>
                        </div>
                        <h3 className="font-semibold mt-3">{movie.title}</h3>
                        <div className="flex items-center justify-between mt-1">
                          <span className="text-sm text-gray-400">{movie.year}</span>
                          <div className="flex items-center">
                            <Star className="w-3 h-3 text-yellow-500 mr-1" />
                            <span className="text-sm">{movie.rating}</span>
                          </div>
                        </div>
                        <div className="flex flex-wrap gap-1 mt-2">
                          {movie.platforms.slice(0, 2).map((platform) => (
                            <Badge key={platform} variant="secondary" className="text-xs">
                              {platform}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="space-y-4">
                    {filteredMovies.map((movie) => (
                      <Card
                        key={movie.id}
                        className="bg-gray-900 border-gray-800 hover:bg-gray-800 transition-colors cursor-pointer"
                        onClick={() => setSelectedMovie(movie)}
                      >
                        <CardContent className="p-4">
                          <div className="flex space-x-4">
                            <Image
                              src={movie.image || "/placeholder.svg"}
                              alt={movie.title}
                              width={120}
                              height={180}
                              className="object-cover rounded-lg"
                            />
                            <div className="flex-1">
                              <div className="flex items-start justify-between">
                                <div>
                                  <h3 className="text-xl font-semibold mb-2">{movie.title}</h3>
                                  <div className="flex items-center space-x-4 mb-2">
                                    <span className="text-gray-400">{movie.year}</span>
                                    <div className="flex items-center">
                                      <Star className="w-4 h-4 text-yellow-500 mr-1" />
                                      <span>{movie.rating}</span>
                                    </div>
                                    <span className="text-gray-400">{movie.duration}</span>
                                  </div>
                                  <div className="flex flex-wrap gap-2 mb-3">
                                    {movie.genre.map((g) => (
                                      <Badge key={g} variant="outline" className="border-gray-600">
                                        {g}
                                      </Badge>
                                    ))}
                                  </div>
                                  <p className="text-gray-400 text-sm mb-3 line-clamp-2">{movie.description}</p>
                                </div>
                                <Button className="bg-red-600 hover:bg-red-700">
                                  <Play className="w-4 h-4 mr-2" />
                                  Watch Now
                                </Button>
                              </div>
                              <div className="flex items-center space-x-2">
                                <span className="text-sm text-gray-400">Available on:</span>
                                {movie.platforms.map((platform) => (
                                  <Badge key={platform} variant="secondary" className="text-xs">
                                    {platform}
                                  </Badge>
                                ))}
                              </div>
                            </div>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </TabsContent>
            </Tabs>
          </div>
        </section>
      </div>

      {/* Movie Detail Modal */}
      {selectedMovie && (
        <div className="fixed inset-0 z-50 bg-black/80 flex items-center justify-center p-4">
          <div className="bg-gray-900 rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="relative">
              <Image
                src={selectedMovie.image || "/placeholder.svg"}
                alt={selectedMovie.title}
                width={800}
                height={400}
                className="w-full h-64 object-cover rounded-t-lg"
              />
              <Button
                variant="ghost"
                size="icon"
                className="absolute top-4 right-4 bg-black/50 hover:bg-black/70"
                onClick={() => setSelectedMovie(null)}
              >
                <X className="w-5 h-5" />
              </Button>
            </div>

            <div className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div>
                  <h2 className="text-3xl font-bold mb-2">{selectedMovie.title}</h2>
                  <div className="flex items-center space-x-4 mb-4">
                    <span className="text-gray-400">{selectedMovie.year}</span>
                    <div className="flex items-center">
                      <Star className="w-4 h-4 text-yellow-500 mr-1" />
                      <span>{selectedMovie.rating}</span>
                    </div>
                    <span className="text-gray-400">{selectedMovie.duration}</span>
                  </div>
                </div>
                <Button size="lg" className="bg-red-600 hover:bg-red-700">
                  <Play className="w-5 h-5 mr-2" />
                  Watch Now
                </Button>
              </div>

              <div className="flex flex-wrap gap-2 mb-4">
                {selectedMovie.genre.map((g) => (
                  <Badge key={g} variant="outline" className="border-gray-600">
                    {g}
                  </Badge>
                ))}
              </div>

              <p className="text-gray-300 mb-6">{selectedMovie.description}</p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div>
                  <h3 className="font-semibold mb-2">Director</h3>
                  <p className="text-gray-400">{selectedMovie.director}</p>
                </div>
                <div>
                  <h3 className="font-semibold mb-2">Cast</h3>
                  <p className="text-gray-400">{selectedMovie.cast.join(", ")}</p>
                </div>
              </div>

              <div className="mt-6">
                <h3 className="font-semibold mb-2">Available on</h3>
                <div className="flex flex-wrap gap-2">
                  {selectedMovie.platforms.map((platform) => (
                    <Badge key={platform} variant="secondary">
                      {platform}
                    </Badge>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}
