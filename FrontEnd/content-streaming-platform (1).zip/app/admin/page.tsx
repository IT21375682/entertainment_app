"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import {
  Plus,
  Trash2,
  Upload,
  Eye,
  BarChart3,
  Users,
  FileText,
  ImageIcon,
  Settings,
  MessageSquare,
  TrendingUp,
  Activity,
} from "lucide-react"

const recentArticles = [
  {
    id: 1,
    title: "Marvel's Phase 5: Everything We Know So Far",
    status: "Published",
    views: "12.5K",
    date: "2 hours ago",
    category: "Movie News",
  },
  {
    id: 2,
    title: "The Batman 2: Production Updates",
    status: "Draft",
    views: "0",
    date: "1 day ago",
    category: "Movie News",
  },
  {
    id: 3,
    title: "Oscars 2024: Predictions and Analysis",
    status: "Scheduled",
    views: "0",
    date: "Tomorrow",
    category: "Awards",
  },
]

const analytics = {
  totalViews: "2.4M",
  totalArticles: 1247,
  totalUsers: "45.2K",
  engagement: "8.7%",
}

export default function AdminDashboard() {
  const [activeTab, setActiveTab] = useState("overview")

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Admin Navigation */}
      <nav className="border-b border-gray-800 bg-gray-950">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center space-x-8">
              <h1 className="text-2xl font-bold text-red-500">StreamNews Admin</h1>
              <div className="flex space-x-6">
                <Button variant="ghost" className="text-gray-300 hover:text-white">
                  <FileText className="w-4 h-4 mr-2" />
                  Content
                </Button>
                <Button variant="ghost" className="text-gray-300 hover:text-white">
                  <ImageIcon className="w-4 h-4 mr-2" />
                  Media
                </Button>
                <Button variant="ghost" className="text-gray-300 hover:text-white">
                  <BarChart3 className="w-4 h-4 mr-2" />
                  Analytics
                </Button>
                <Button variant="ghost" className="text-gray-300 hover:text-white">
                  <Users className="w-4 h-4 mr-2" />
                  Users
                </Button>
              </div>
            </div>
            <div className="flex items-center space-x-4">
              <Button className="bg-red-600 hover:bg-red-700">
                <Plus className="w-4 h-4 mr-2" />
                New Article
              </Button>
              <Button variant="outline" className="border-gray-700 bg-transparent">
                <Settings className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </div>
      </nav>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
          <TabsList className="grid w-full grid-cols-5 bg-gray-900">
            <TabsTrigger value="overview">Overview</TabsTrigger>
            <TabsTrigger value="content">Content</TabsTrigger>
            <TabsTrigger value="media">Media Library</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
          </TabsList>

          {/* Overview Tab */}
          <TabsContent value="overview" className="space-y-6">
            {/* Stats Cards */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <Card className="bg-gray-900 border-gray-800">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Total Views</CardTitle>
                  <Eye className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{analytics.totalViews}</div>
                  <p className="text-xs text-muted-foreground">+12.5% from last month</p>
                </CardContent>
              </Card>

              <Card className="bg-gray-900 border-gray-800">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Articles</CardTitle>
                  <FileText className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{analytics.totalArticles}</div>
                  <p className="text-xs text-muted-foreground">+23 this month</p>
                </CardContent>
              </Card>

              <Card className="bg-gray-900 border-gray-800">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Subscribers</CardTitle>
                  <Users className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{analytics.totalUsers}</div>
                  <p className="text-xs text-muted-foreground">+8.2% from last month</p>
                </CardContent>
              </Card>

              <Card className="bg-gray-900 border-gray-800">
                <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                  <CardTitle className="text-sm font-medium">Engagement</CardTitle>
                  <TrendingUp className="h-4 w-4 text-muted-foreground" />
                </CardHeader>
                <CardContent>
                  <div className="text-2xl font-bold">{analytics.engagement}</div>
                  <p className="text-xs text-muted-foreground">+2.1% from last month</p>
                </CardContent>
              </Card>
            </div>

            {/* Recent Activity */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-gray-900 border-gray-800">
                <CardHeader>
                  <CardTitle>Recent Articles</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {recentArticles.map((article) => (
                      <div key={article.id} className="flex items-center justify-between">
                        <div className="flex-1">
                          <h4 className="font-medium line-clamp-1">{article.title}</h4>
                          <div className="flex items-center space-x-2 text-sm text-gray-400">
                            <Badge variant="outline" className="border-gray-600">
                              {article.category}
                            </Badge>
                            <span>{article.date}</span>
                          </div>
                        </div>
                        <div className="flex items-center space-x-2">
                          <Badge
                            variant={article.status === "Published" ? "default" : "secondary"}
                            className={article.status === "Published" ? "bg-green-600" : ""}
                          >
                            {article.status}
                          </Badge>
                          <span className="text-sm text-gray-400">{article.views}</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gray-900 border-gray-800">
                <CardHeader>
                  <CardTitle>Quick Actions</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="grid grid-cols-2 gap-4">
                    <Button className="h-20 flex-col bg-red-600 hover:bg-red-700">
                      <Plus className="w-6 h-6 mb-2" />
                      New Article
                    </Button>
                    <Button variant="outline" className="h-20 flex-col border-gray-700 bg-transparent">
                      <Upload className="w-6 h-6 mb-2" />
                      Upload Media
                    </Button>
                    <Button variant="outline" className="h-20 flex-col border-gray-700 bg-transparent">
                      <MessageSquare className="w-6 h-6 mb-2" />
                      Comments
                    </Button>
                    <Button variant="outline" className="h-20 flex-col border-gray-700 bg-transparent">
                      <Activity className="w-6 h-6 mb-2" />
                      Analytics
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Content Tab */}
          <TabsContent value="content" className="space-y-6">
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle>Create New Article</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="title">Article Title</Label>
                      <Input id="title" placeholder="Enter article title..." className="bg-gray-800 border-gray-700" />
                    </div>

                    <div>
                      <Label htmlFor="category">Category</Label>
                      <Select>
                        <SelectTrigger className="bg-gray-800 border-gray-700">
                          <SelectValue placeholder="Select category" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="movie-news">Movie News</SelectItem>
                          <SelectItem value="sports-news">Sports News</SelectItem>
                          <SelectItem value="blog">Blog</SelectItem>
                          <SelectItem value="video-posts">Video Posts</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <div>
                      <Label htmlFor="tags">Tags</Label>
                      <Input
                        id="tags"
                        placeholder="Enter tags separated by commas..."
                        className="bg-gray-800 border-gray-700"
                      />
                    </div>

                    <div>
                      <Label htmlFor="excerpt">Excerpt</Label>
                      <Textarea
                        id="excerpt"
                        placeholder="Brief description of the article..."
                        className="bg-gray-800 border-gray-700"
                        rows={3}
                      />
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div>
                      <Label>Featured Image</Label>
                      <div className="border-2 border-dashed border-gray-700 rounded-lg p-8 text-center">
                        <Upload className="w-12 h-12 mx-auto mb-4 text-gray-400" />
                        <p className="text-gray-400 mb-2">Drop image here or click to upload</p>
                        <Button variant="outline" className="border-gray-700 bg-transparent">
                          Choose File
                        </Button>
                      </div>
                    </div>

                    <div className="space-y-4">
                      <div className="flex items-center justify-between">
                        <Label htmlFor="featured">Featured Article</Label>
                        <Switch id="featured" />
                      </div>

                      <div className="flex items-center justify-between">
                        <Label htmlFor="comments">Allow Comments</Label>
                        <Switch id="comments" defaultChecked />
                      </div>

                      <div>
                        <Label htmlFor="publish-date">Publish Date</Label>
                        <Input id="publish-date" type="datetime-local" className="bg-gray-800 border-gray-700" />
                      </div>
                    </div>
                  </div>
                </div>

                <div>
                  <Label htmlFor="content">Article Content</Label>
                  <Textarea
                    id="content"
                    placeholder="Write your article content here..."
                    className="bg-gray-800 border-gray-700 min-h-[300px]"
                  />
                </div>

                <div className="flex justify-end space-x-4">
                  <Button variant="outline" className="border-gray-700 bg-transparent">
                    Save Draft
                  </Button>
                  <Button variant="outline" className="border-gray-700 bg-transparent">
                    Preview
                  </Button>
                  <Button className="bg-red-600 hover:bg-red-700">Publish</Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Media Library Tab */}
          <TabsContent value="media" className="space-y-6">
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader className="flex flex-row items-center justify-between">
                <CardTitle>Media Library</CardTitle>
                <Button className="bg-red-600 hover:bg-red-700">
                  <Upload className="w-4 h-4 mr-2" />
                  Upload Files
                </Button>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
                  {Array.from({ length: 12 }).map((_, i) => (
                    <div key={i} className="relative group cursor-pointer">
                      <div className="aspect-square bg-gray-800 rounded-lg overflow-hidden">
                        <div className="w-full h-full flex items-center justify-center">
                          <ImageIcon className="w-8 h-8 text-gray-600" />
                        </div>
                      </div>
                      <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity rounded-lg flex items-center justify-center">
                        <div className="flex space-x-2">
                          <Button size="icon" variant="secondary" className="w-8 h-8">
                            <Eye className="w-4 h-4" />
                          </Button>
                          <Button size="icon" variant="secondary" className="w-8 h-8">
                            <Trash2 className="w-4 h-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          {/* Analytics Tab */}
          <TabsContent value="analytics" className="space-y-6">
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <Card className="bg-gray-900 border-gray-800">
                <CardHeader>
                  <CardTitle>Traffic Overview</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="h-64 bg-gray-800 rounded-lg flex items-center justify-center">
                    <p className="text-gray-400">Traffic Chart Placeholder</p>
                  </div>
                </CardContent>
              </Card>

              <Card className="bg-gray-900 border-gray-800">
                <CardHeader>
                  <CardTitle>Top Articles</CardTitle>
                </CardHeader>
                <CardContent>
                  <div className="space-y-4">
                    {recentArticles.map((article, index) => (
                      <div key={article.id} className="flex items-center justify-between">
                        <div className="flex items-center space-x-3">
                          <span className="text-2xl font-bold text-gray-500">#{index + 1}</span>
                          <div>
                            <h4 className="font-medium line-clamp-1">{article.title}</h4>
                            <p className="text-sm text-gray-400">{article.category}</p>
                          </div>
                        </div>
                        <div className="text-right">
                          <p className="font-semibold">{article.views}</p>
                          <p className="text-sm text-gray-400">views</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </CardContent>
              </Card>
            </div>
          </TabsContent>

          {/* Settings Tab */}
          <TabsContent value="settings" className="space-y-6">
            <Card className="bg-gray-900 border-gray-800">
              <CardHeader>
                <CardTitle>Site Settings</CardTitle>
              </CardHeader>
              <CardContent className="space-y-6">
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div>
                      <Label htmlFor="site-title">Site Title</Label>
                      <Input id="site-title" defaultValue="StreamNews" className="bg-gray-800 border-gray-700" />
                    </div>

                    <div>
                      <Label htmlFor="site-description">Site Description</Label>
                      <Textarea
                        id="site-description"
                        defaultValue="Your ultimate destination for entertainment news and streaming content."
                        className="bg-gray-800 border-gray-700"
                        rows={3}
                      />
                    </div>

                    <div>
                      <Label htmlFor="contact-email">Contact Email</Label>
                      <Input
                        id="contact-email"
                        type="email"
                        defaultValue="admin@streamnews.com"
                        className="bg-gray-800 border-gray-700"
                      />
                    </div>
                  </div>

                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <Label htmlFor="comments-enabled">Enable Comments</Label>
                      <Switch id="comments-enabled" defaultChecked />
                    </div>

                    <div className="flex items-center justify-between">
                      <Label htmlFor="newsletter-enabled">Newsletter Signup</Label>
                      <Switch id="newsletter-enabled" defaultChecked />
                    </div>

                    <div className="flex items-center justify-between">
                      <Label htmlFor="analytics-enabled">Analytics Tracking</Label>
                      <Switch id="analytics-enabled" defaultChecked />
                    </div>

                    <div>
                      <Label htmlFor="posts-per-page">Posts Per Page</Label>
                      <Select defaultValue="12">
                        <SelectTrigger className="bg-gray-800 border-gray-700">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="6">6</SelectItem>
                          <SelectItem value="12">12</SelectItem>
                          <SelectItem value="18">18</SelectItem>
                          <SelectItem value="24">24</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>

                <div className="flex justify-end">
                  <Button className="bg-red-600 hover:bg-red-700">Save Settings</Button>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  )
}
