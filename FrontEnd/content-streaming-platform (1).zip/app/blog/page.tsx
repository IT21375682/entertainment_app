"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, Calendar, User, Clock, Bookmark, Share2, Eye, TrendingUp, MessageCircle } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

const blogPosts = [
  {
    id: 1,
    title: "The Evolution of Streaming: How Netflix Changed Entertainment Forever",
    description:
      "A deep dive into how Netflix revolutionized the entertainment industry and what it means for the future of content consumption.",
    image: "/placeholder.svg?height=400&width=600",
    author: "Alex Chen",
    date: "3 hours ago",
    readTime: "12 min read",
    category: "Technology",
    tags: ["Streaming", "Netflix", "Entertainment", "Technology"],
    views: "24.8K",
    comments: 156,
    featured: true,
    type: "Analysis",
  },
  {
    id: 2,
    title: "Behind the Scenes: What Makes a Movie Blockbuster in 2024",
    description:
      "Exploring the key ingredients that transform a regular film into a box office phenomenon in today's entertainment landscape.",
    image: "/placeholder.svg?height=400&width=600",
    author: "Sarah Johnson",
    date: "5 hours ago",
    readTime: "10 min read",
    category: "Industry",
    tags: ["Movies", "Box Office", "Industry", "Analysis"],
    views: "18.3K",
    comments: 89,
    featured: true,
    type: "Industry Insight",
  },
  {
    id: 3,
    title: "The Psychology of Binge-Watching: Why We Can't Stop",
    description:
      "Understanding the psychological factors that make streaming shows so addictive and how platforms design content to keep us watching.",
    image: "/placeholder.svg?height=400&width=600",
    author: "Dr. Emma Davis",
    date: "1 day ago",
    readTime: "8 min read",
    category: "Psychology",
    tags: ["Psychology", "Binge-watching", "Streaming", "Behavior"],
    views: "15.7K",
    comments: 203,
    featured: false,
    type: "Research",
  },
  {
    id: 4,
    title: "From Script to Screen: The Modern Filmmaking Process",
    description:
      "A comprehensive guide to how movies are made today, from initial concept to final release, including the role of technology.",
    image: "/placeholder.svg?height=400&width=600",
    author: "Michael Rodriguez",
    date: "2 days ago",
    readTime: "15 min read",
    category: "Filmmaking",
    tags: ["Filmmaking", "Production", "Technology", "Process"],
    views: "12.4K",
    comments: 67,
    featured: false,
    type: "Guide",
  },
  {
    id: 5,
    title: "The Rise of International Content: Breaking Language Barriers",
    description:
      "How shows like Squid Game and Money Heist proved that great content transcends language and cultural boundaries.",
    image: "/placeholder.svg?height=400&width=600",
    author: "Lisa Park",
    date: "3 days ago",
    readTime: "9 min read",
    category: "Global",
    tags: ["International", "Squid Game", "Global Content", "Culture"],
    views: "21.2K",
    comments: 134,
    featured: false,
    type: "Cultural Analysis",
  },
  {
    id: 6,
    title: "AI in Entertainment: The Future of Content Creation",
    description:
      "Exploring how artificial intelligence is being used in movie production, script writing, and content recommendation systems.",
    image: "/placeholder.svg?height=400&width=600",
    author: "David Wilson",
    date: "4 days ago",
    readTime: "11 min read",
    category: "Technology",
    tags: ["AI", "Technology", "Future", "Content Creation"],
    views: "19.6K",
    comments: 98,
    featured: false,
    type: "Technology",
  },
  {
    id: 7,
    title: "The Economics of Streaming Wars: Who's Winning?",
    description:
      "A financial analysis of the major streaming platforms and their strategies for dominating the entertainment market.",
    image: "/placeholder.svg?height=400&width=600",
    author: "Jennifer Martinez",
    date: "5 days ago",
    readTime: "13 min read",
    category: "Business",
    tags: ["Streaming Wars", "Economics", "Business", "Competition"],
    views: "16.8K",
    comments: 112,
    featured: false,
    type: "Business Analysis",
  },
  {
    id: 8,
    title: "Nostalgia Marketing: Why Reboots and Remakes Dominate",
    description:
      "Understanding the psychological and economic reasons behind Hollywood's obsession with reboots, remakes, and nostalgic content.",
    image: "/placeholder.svg?height=400&width=600",
    author: "Tom Anderson",
    date: "1 week ago",
    readTime: "7 min read",
    category: "Marketing",
    tags: ["Nostalgia", "Marketing", "Reboots", "Psychology"],
    views: "13.5K",
    comments: 76,
    featured: false,
    type: "Marketing",
  },
]

const blogCategories = ["All", "Technology", "Industry", "Psychology", "Filmmaking", "Global", "Business", "Marketing"]
const sortOptions = ["Latest", "Most Popular", "Most Commented", "Oldest"]

const trendingTopics = [
  { topic: "Streaming Wars", count: "45 articles" },
  { topic: "AI in Entertainment", count: "32 articles" },
  { topic: "International Content", count: "28 articles" },
  { topic: "Box Office Analysis", count: "24 articles" },
  { topic: "Future of Cinema", count: "19 articles" },
]

export default function BlogPage() {
  const [selectedCategory, setSelectedCategory] = useState("All")
  const [sortBy, setSortBy] = useState("Latest")
  const [searchQuery, setSearchQuery] = useState("")

  const filteredPosts = blogPosts.filter((post) => {
    const categoryMatch = selectedCategory === "All" || post.category === selectedCategory
    const searchMatch =
      post.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      post.description.toLowerCase().includes(searchQuery.toLowerCase())
    return categoryMatch && searchMatch
  })

  const featuredPosts = filteredPosts.filter((post) => post.featured)
  const regularPosts = filteredPosts.filter((post) => !post.featured)

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Navigation */}
      <nav className="fixed top-0 w-full z-50 bg-black/90 backdrop-blur-md border-b border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link href="/" className="text-2xl font-bold text-red-500">
              StreamNews
            </Link>
            <div className="flex items-center space-x-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search blog posts..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 bg-gray-900 border-gray-700 text-white placeholder-gray-400 w-64"
                />
              </div>
            </div>
          </div>
        </div>
      </nav>

      <div className="pt-16">
        {/* Hero Section */}
        <section className="relative h-96 overflow-hidden">
          <Image src="/placeholder.svg?height=400&width=1440" alt="Blog" fill className="object-cover" />
          <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/40 to-transparent" />
          <div className="relative z-10 flex items-center h-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div>
              <h1 className="text-5xl font-bold mb-4">Entertainment Blog</h1>
              <p className="text-xl text-gray-300 max-w-2xl">
                Deep insights, analysis, and thought-provoking articles about the entertainment industry
              </p>
            </div>
          </div>
        </section>

        {/* Trending Topics */}
        <section className="py-8 bg-gray-950 border-b border-gray-800">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between mb-6">
              <h2 className="text-lg font-bold flex items-center">
                <TrendingUp className="w-5 h-5 mr-2 text-red-500" />
                Trending Topics
              </h2>
            </div>
            <div className="flex items-center space-x-4 overflow-x-auto">
              {trendingTopics.map((topic) => (
                <Card
                  key={topic.topic}
                  className="bg-gray-900 border-gray-800 hover:bg-gray-800 transition-colors cursor-pointer min-w-fit"
                >
                  <CardContent className="p-4">
                    <h3 className="font-semibold text-sm mb-1">{topic.topic}</h3>
                    <p className="text-xs text-gray-400">{topic.count}</p>
                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Category Filter */}
        <section className="py-6 bg-gray-950 border-b border-gray-800">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4 overflow-x-auto">
                {blogCategories.map((category) => (
                  <Button
                    key={category}
                    variant={selectedCategory === category ? "default" : "outline"}
                    onClick={() => setSelectedCategory(category)}
                    className={`whitespace-nowrap ${
                      selectedCategory === category
                        ? "bg-red-600 hover:bg-red-700"
                        : "border-gray-700 hover:bg-gray-800"
                    }`}
                  >
                    {category}
                  </Button>
                ))}
              </div>

              <div className="flex items-center space-x-4">
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="w-40 bg-gray-900 border-gray-700">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {sortOptions.map((option) => (
                      <SelectItem key={option} value={option}>
                        {option}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        </section>

        {/* Featured Posts */}
        {featuredPosts.length > 0 && (
          <section className="py-12 bg-gray-950">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <h2 className="text-2xl font-bold mb-8">Featured Articles</h2>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {featuredPosts.map((post, index) => (
                  <Card
                    key={post.id}
                    className={`bg-gray-900 border-gray-800 hover:bg-gray-800 transition-colors group cursor-pointer ${
                      index === 0 ? "lg:col-span-2" : ""
                    }`}
                  >
                    <div className="relative overflow-hidden">
                      <Image
                        src={post.image || "/placeholder.svg"}
                        alt={post.title}
                        width={600}
                        height={index === 0 ? 300 : 400}
                        className={`object-cover w-full group-hover:scale-105 transition-transform duration-300 ${
                          index === 0 ? "h-64" : "h-48"
                        }`}
                      />
                      <Badge className="absolute top-4 left-4 bg-red-600">Featured</Badge>
                      <Badge variant="secondary" className="absolute top-4 right-4">
                        {post.type}
                      </Badge>
                    </div>
                    <CardContent className="p-6">
                      <div className="flex items-center space-x-2 mb-3">
                        <Badge variant="outline" className="border-gray-600">
                          {post.category}
                        </Badge>
                      </div>
                      <h3
                        className={`font-bold mb-3 group-hover:text-red-400 transition-colors ${
                          index === 0 ? "text-2xl" : "text-xl"
                        }`}
                      >
                        {post.title}
                      </h3>
                      <p className="text-gray-400 mb-4 line-clamp-2">{post.description}</p>
                      <div className="flex items-center justify-between text-sm text-gray-500">
                        <div className="flex items-center space-x-4">
                          <div className="flex items-center space-x-1">
                            <User className="w-3 h-3" />
                            <span>{post.author}</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <Calendar className="w-3 h-3" />
                            <span>{post.date}</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <Clock className="w-3 h-3" />
                            <span>{post.readTime}</span>
                          </div>
                        </div>
                        <div className="flex items-center space-x-4">
                          <div className="flex items-center space-x-1">
                            <Eye className="w-3 h-3" />
                            <span>{post.views}</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <MessageCircle className="w-3 h-3" />
                            <span>{post.comments}</span>
                          </div>
                          <Button variant="ghost" size="icon" className="w-6 h-6">
                            <Bookmark className="w-3 h-3" />
                          </Button>
                          <Button variant="ghost" size="icon" className="w-6 h-6">
                            <Share2 className="w-3 h-3" />
                          </Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </section>
        )}

        {/* Regular Posts */}
        <section className="py-12 bg-black">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-2xl font-bold">Latest Articles</h2>
              <span className="text-gray-400">{filteredPosts.length} articles</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {regularPosts.map((post) => (
                <Card
                  key={post.id}
                  className="bg-gray-900 border-gray-800 hover:bg-gray-800 transition-colors group cursor-pointer"
                >
                  <div className="relative overflow-hidden">
                    <Image
                      src={post.image || "/placeholder.svg"}
                      alt={post.title}
                      width={400}
                      height={250}
                      className="object-cover w-full h-48 group-hover:scale-105 transition-transform duration-300"
                    />
                    <Badge variant="secondary" className="absolute top-3 left-3">
                      {post.type}
                    </Badge>
                  </div>
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-2 mb-2">
                      <Badge variant="outline" className="text-xs border-gray-600">
                        {post.category}
                      </Badge>
                    </div>
                    <h3 className="font-semibold text-lg mb-2 line-clamp-2 group-hover:text-red-400 transition-colors">
                      {post.title}
                    </h3>
                    <p className="text-gray-400 text-sm mb-4 line-clamp-2">{post.description}</p>
                    <div className="flex flex-wrap gap-1 mb-4">
                      {post.tags.slice(0, 3).map((tag) => (
                        <Badge key={tag} variant="outline" className="text-xs border-gray-600">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                    <div className="flex items-center justify-between text-xs text-gray-500">
                      <div className="flex items-center space-x-2">
                        <User className="w-3 h-3" />
                        <span>{post.author}</span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <span>{post.date}</span>
                        <span>{post.readTime}</span>
                        <div className="flex items-center space-x-1">
                          <Eye className="w-3 h-3" />
                          <span>{post.views}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <MessageCircle className="w-3 h-3" />
                          <span>{post.comments}</span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Load More Button */}
            <div className="text-center mt-12">
              <Button className="bg-red-600 hover:bg-red-700">Load More Articles</Button>
            </div>
          </div>
        </section>

        {/* Newsletter Signup */}
        <section className="py-16 bg-gray-900">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-3xl font-bold mb-4">Join Our Community</h2>
            <p className="text-gray-400 mb-8">
              Get exclusive insights, behind-the-scenes content, and thought-provoking articles delivered to your inbox.
            </p>
            <div className="flex max-w-md mx-auto">
              <Input placeholder="Enter your email" className="rounded-r-none bg-gray-800 border-gray-700" />
              <Button className="rounded-l-none bg-red-600 hover:bg-red-700">Subscribe</Button>
            </div>
          </div>
        </section>
      </div>
    </div>
  )
}
