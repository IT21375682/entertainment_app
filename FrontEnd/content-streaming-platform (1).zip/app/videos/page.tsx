"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Search, Calendar, User, Play, Eye, ThumbsUp, MessageCircle } from "lucide-react"
import Image from "next/image"
import Link from "next/link"

const videoContent = [
  {
    id: 1,
    title: "Marvel Phase 5 Breakdown: Every Movie & Series Explained",
    description:
      "A comprehensive video breakdown of Marvel's Phase 5 plans, including exclusive interviews and behind-the-scenes footage.",
    thumbnail: "/placeholder.svg?height=300&width=500",
    duration: "15:42",
    author: "Sarah Johnson",
    date: "2 hours ago",
    category: "Movie Analysis",
    tags: ["Marvel", "Phase 5", "MCU", "Analysis"],
    views: "125K",
    likes: "8.2K",
    comments: 342,
    featured: true,
    type: "Analysis",
  },
  {
    id: 2,
    title: "Behind the Scenes: The Batman 2 Set Visit",
    description: "Exclusive behind-the-scenes footage from The Batman 2 set, featuring interviews with cast and crew.",
    thumbnail: "/placeholder.svg?height=300&width=500",
    duration: "12:18",
    author: "Mike Rodriguez",
    date: "4 hours ago",
    category: "Behind the Scenes",
    tags: ["Batman", "DC", "Behind the Scenes", "Exclusive"],
    views: "89K",
    likes: "6.7K",
    comments: 198,
    featured: true,
    type: "Exclusive",
  },
  {
    id: 3,
    title: "Top 10 Netflix Originals You Must Watch in 2024",
    description:
      "Our curated list of the best Netflix original content coming this year, with trailers and exclusive clips.",
    thumbnail: "/placeholder.svg?height=300&width=500",
    duration: "18:25",
    author: "Emma Davis",
    date: "6 hours ago",
    category: "Reviews",
    tags: ["Netflix", "Originals", "2024", "Reviews"],
    views: "67K",
    likes: "4.3K",
    comments: 156,
    featured: false,
    type: "Review",
  },
  {
    id: 4,
    title: "Oscars 2024 Predictions: Who Will Win?",
    description: "Our expert panel discusses the top contenders for this year's Academy Awards with detailed analysis.",
    thumbnail: "/placeholder.svg?height=300&width=500",
    duration: "22:14",
    author: "Alex Chen",
    date: "8 hours ago",
    category: "Awards",
    tags: ["Oscars", "2024", "Predictions", "Awards"],
    views: "112K",
    likes: "7.8K",
    comments: 289,
    featured: false,
    type: "Discussion",
  },
  {
    id: 5,
    title: "The Making of Dune: Part Two - Director's Commentary",
    description:
      "Denis Villeneuve takes us through the making of Dune: Part Two with exclusive commentary and deleted scenes.",
    thumbnail: "/placeholder.svg?height=300&width=500",
    duration: "28:33",
    author: "David Wilson",
    date: "12 hours ago",
    category: "Director's Cut",
    tags: ["Dune", "Denis Villeneuve", "Commentary", "Making Of"],
    views: "156K",
    likes: "12.1K",
    comments: 445,
    featured: false,
    type: "Commentary",
  },
  {
    id: 6,
    title: "Stranger Things Season 5: Everything We Know",
    description: "All the latest updates, theories, and exclusive content about the final season of Stranger Things.",
    thumbnail: "/placeholder.svg?height=300&width=500",
    duration: "14:07",
    author: "Lisa Park",
    date: "1 day ago",
    category: "Series Analysis",
    tags: ["Stranger Things", "Season 5", "Netflix", "Theories"],
    views: "203K",
    likes: "15.6K",
    comments: 567,
    featured: false,
    type: "Analysis",
  },
]

const videoCategories = [
  "All",
  "Movie Analysis",
  "Behind the Scenes",
  "Reviews",
  "Awards",
  "Director's Cut",
  "Series Analysis",
]
const sortOptions = ["Latest", "Most Viewed", "Most Liked", "Longest", "Shortest"]

export default function VideosPage() {
  const [selectedCategory, setSelectedCategory] = useState("All")
  const [sortBy, setSortBy] = useState("Latest")
  const [searchQuery, setSearchQuery] = useState("")

  const filteredVideos = videoContent.filter((video) => {
    const categoryMatch = selectedCategory === "All" || video.category === selectedCategory
    const searchMatch =
      video.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      video.description.toLowerCase().includes(searchQuery.toLowerCase())
    return categoryMatch && searchMatch
  })

  const featuredVideos = filteredVideos.filter((video) => video.featured)
  const regularVideos = filteredVideos.filter((video) => !video.featured)

  return (
    <div className="min-h-screen bg-black text-white">
      {/* Navigation */}
      <nav className="fixed top-0 w-full z-50 bg-black/90 backdrop-blur-md border-b border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <Link href="/" className="text-2xl font-bold text-red-500">
              StreamNews
            </Link>
            <div className="flex items-center space-x-4">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                <Input
                  placeholder="Search videos..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                  className="pl-10 bg-gray-900 border-gray-700 text-white placeholder-gray-400 w-64"
                />
              </div>
            </div>
          </div>
        </div>
      </nav>

      <div className="pt-16">
        {/* Hero Section */}
        <section className="relative h-96 overflow-hidden">
          <Image src="/placeholder.svg?height=400&width=1440" alt="Video Content" fill className="object-cover" />
          <div className="absolute inset-0 bg-gradient-to-r from-black/80 via-black/40 to-transparent" />
          <div className="relative z-10 flex items-center h-full max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div>
              <h1 className="text-5xl font-bold mb-4">Video Content</h1>
              <p className="text-xl text-gray-300 max-w-2xl">
                Exclusive videos, behind-the-scenes content, and in-depth analysis from the entertainment world
              </p>
            </div>
          </div>
        </section>

        {/* Category Filter */}
        <section className="py-6 bg-gray-950 border-b border-gray-800">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-4 overflow-x-auto">
                {videoCategories.map((category) => (
                  <Button
                    key={category}
                    variant={selectedCategory === category ? "default" : "outline"}
                    onClick={() => setSelectedCategory(category)}
                    className={`whitespace-nowrap ${
                      selectedCategory === category
                        ? "bg-red-600 hover:bg-red-700"
                        : "border-gray-700 hover:bg-gray-800"
                    }`}
                  >
                    {category}
                  </Button>
                ))}
              </div>

              <div className="flex items-center space-x-4">
                <Select value={sortBy} onValueChange={setSortBy}>
                  <SelectTrigger className="w-32 bg-gray-900 border-gray-700">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    {sortOptions.map((option) => (
                      <SelectItem key={option} value={option}>
                        {option}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        </section>

        {/* Featured Videos */}
        {featuredVideos.length > 0 && (
          <section className="py-12 bg-gray-950">
            <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
              <h2 className="text-2xl font-bold mb-8">Featured Videos</h2>
              <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
                {featuredVideos.map((video, index) => (
                  <Card
                    key={video.id}
                    className={`bg-gray-900 border-gray-800 hover:bg-gray-800 transition-colors group cursor-pointer ${
                      index === 0 ? "lg:col-span-2" : ""
                    }`}
                  >
                    <div className="relative overflow-hidden">
                      <Image
                        src={video.thumbnail || "/placeholder.svg"}
                        alt={video.title}
                        width={500}
                        height={index === 0 ? 300 : 300}
                        className={`object-cover w-full group-hover:scale-105 transition-transform duration-300 ${
                          index === 0 ? "h-64" : "h-48"
                        }`}
                      />
                      <div className="absolute inset-0 bg-black/40 group-hover:bg-black/60 transition-colors flex items-center justify-center">
                        <div className="bg-red-600 rounded-full p-4 group-hover:scale-110 transition-transform">
                          <Play className="w-8 h-8 text-white" />
                        </div>
                      </div>
                      <Badge className="absolute top-4 left-4 bg-red-600">Featured</Badge>
                      <Badge variant="secondary" className="absolute top-4 right-4">
                        {video.type}
                      </Badge>
                      <div className="absolute bottom-4 right-4 bg-black/80 px-2 py-1 rounded text-sm font-medium">
                        {video.duration}
                      </div>
                    </div>
                    <CardContent className="p-6">
                      <div className="flex items-center space-x-2 mb-3">
                        <Badge variant="outline" className="border-gray-600">
                          {video.category}
                        </Badge>
                      </div>
                      <h3
                        className={`font-bold mb-3 group-hover:text-red-400 transition-colors ${
                          index === 0 ? "text-2xl" : "text-xl"
                        }`}
                      >
                        {video.title}
                      </h3>
                      <p className="text-gray-400 mb-4 line-clamp-2">{video.description}</p>
                      <div className="flex items-center justify-between text-sm text-gray-500">
                        <div className="flex items-center space-x-4">
                          <div className="flex items-center space-x-1">
                            <User className="w-3 h-3" />
                            <span>{video.author}</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <Calendar className="w-3 h-3" />
                            <span>{video.date}</span>
                          </div>
                        </div>
                        <div className="flex items-center space-x-4">
                          <div className="flex items-center space-x-1">
                            <Eye className="w-3 h-3" />
                            <span>{video.views}</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <ThumbsUp className="w-3 h-3" />
                            <span>{video.likes}</span>
                          </div>
                          <div className="flex items-center space-x-1">
                            <MessageCircle className="w-3 h-3" />
                            <span>{video.comments}</span>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            </div>
          </section>
        )}

        {/* Regular Videos */}
        <section className="py-12 bg-black">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div className="flex items-center justify-between mb-8">
              <h2 className="text-2xl font-bold">Latest Videos</h2>
              <span className="text-gray-400">{filteredVideos.length} videos</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {regularVideos.map((video) => (
                <Card
                  key={video.id}
                  className="bg-gray-900 border-gray-800 hover:bg-gray-800 transition-colors group cursor-pointer"
                >
                  <div className="relative overflow-hidden">
                    <Image
                      src={video.thumbnail || "/placeholder.svg"}
                      alt={video.title}
                      width={400}
                      height={250}
                      className="object-cover w-full h-48 group-hover:scale-105 transition-transform duration-300"
                    />
                    <div className="absolute inset-0 bg-black/40 group-hover:bg-black/60 transition-colors flex items-center justify-center">
                      <div className="bg-red-600 rounded-full p-3 group-hover:scale-110 transition-transform">
                        <Play className="w-6 h-6 text-white" />
                      </div>
                    </div>
                    <Badge variant="secondary" className="absolute top-3 left-3">
                      {video.type}
                    </Badge>
                    <div className="absolute bottom-3 right-3 bg-black/80 px-2 py-1 rounded text-xs font-medium">
                      {video.duration}
                    </div>
                  </div>
                  <CardContent className="p-4">
                    <div className="flex items-center space-x-2 mb-2">
                      <Badge variant="outline" className="text-xs border-gray-600">
                        {video.category}
                      </Badge>
                    </div>
                    <h3 className="font-semibold text-lg mb-2 line-clamp-2 group-hover:text-red-400 transition-colors">
                      {video.title}
                    </h3>
                    <p className="text-gray-400 text-sm mb-4 line-clamp-2">{video.description}</p>
                    <div className="flex flex-wrap gap-1 mb-4">
                      {video.tags.slice(0, 3).map((tag) => (
                        <Badge key={tag} variant="outline" className="text-xs border-gray-600">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                    <div className="flex items-center justify-between text-xs text-gray-500">
                      <div className="flex items-center space-x-2">
                        <User className="w-3 h-3" />
                        <span>{video.author}</span>
                      </div>
                      <div className="flex items-center space-x-3">
                        <div className="flex items-center space-x-1">
                          <Eye className="w-3 h-3" />
                          <span>{video.views}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <ThumbsUp className="w-3 h-3" />
                          <span>{video.likes}</span>
                        </div>
                        <div className="flex items-center space-x-1">
                          <MessageCircle className="w-3 h-3" />
                          <span>{video.comments}</span>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              ))}
            </div>

            {/* Load More Button */}
            <div className="text-center mt-12">
              <Button className="bg-red-600 hover:bg-red-700">Load More Videos</Button>
            </div>
          </div>
        </section>

        {/* Newsletter Signup */}
        <section className="py-16 bg-gray-900">
          <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
            <h2 className="text-3xl font-bold mb-4">Never Miss New Content</h2>
            <p className="text-gray-400 mb-8">
              Subscribe to get notified when we release new videos, exclusive content, and behind-the-scenes footage.
            </p>
            <div className="flex max-w-md mx-auto">
              <Input placeholder="Enter your email" className="rounded-r-none bg-gray-800 border-gray-700" />
              <Button className="rounded-l-none bg-red-600 hover:bg-red-700">Subscribe</Button>
            </div>
          </div>
        </section>
      </div>
    </div>
  )
}
